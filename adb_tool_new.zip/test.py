from Adb import MyclassAdb
import os
#os.popen("adb pull /sdcard/screenshot.png 466666.png")
x=MyclassAdb()
x.adb("adb shell /system/bin/screencap -p /sdcard/screenshot.png")
x.adb("adb pull /sdcard/screenshot.png F:/python/adb_tool/dist/5788666.png")